# Kyphosis-Disease-predictor
Machine Learning |Kyphosis Disease predictor
